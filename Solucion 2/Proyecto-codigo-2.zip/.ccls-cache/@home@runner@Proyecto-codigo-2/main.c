#include <stdio.h>

int main(void) {
  char categoria;
  char pregunta;
  int cantidadGerentes = 0, cantidadEmpleadosHorario = 0, cantidadEmpleadosComision = 0; 
  double totalSueldoGerentes = 0, totalSueldoEmpleadosHorario = 0, 
  totalSueldoEmpleadosComision = 0;

  printf("Desea ingresar un empleado? (S/N): ");
  scanf(" %c", &pregunta);

  while (pregunta == 'S' || pregunta == 's'){
    printf ("Ingresar la categoría:\nG= Gerente\nH= Trabajador con Horario\nC= Trabajador a Comisión: "); 
    scanf(" %c", &categoria);

    switch(categoria){
      case 'G': 
      case 'g':
        {
          double sueldoGerente = 1380.57; 
          cantidadGerentes++; 
          totalSueldoGerentes += sueldoGerente; 

          printf("Monto a pagar al Gerente: %.2f dólares\n", sueldoGerente);
          break;
        }
      case 'H': 
      case 'h': 
        {
          double salarioHorario = 560.84; 
          int horasTrabajadas; 
          double salarioTotal; 

          printf ("Ingrese la cantidad de horas trabajadas por el empleado categoria H: "); 
          scanf("%d", &horasTrabajadas); 

          if (horasTrabajadas <= 40){
            salarioTotal = salarioHorario;
          } else {
            int horasExtras = horasTrabajadas - 40; 
            salarioTotal = salarioHorario + 1.5 * salarioHorario * horasExtras; 
          }
        cantidadEmpleadosHorario++; 
          totalSueldoEmpleadosHorario += salarioTotal;

          printf("Monto a pagar al empleado categoria H: %.2f dólares\n", salarioTotal);
          break; 
        }
      case 'C': 
      case 'c': 
        {
          double salarioBaseComision = 425.99; 
          double porcentajeVentas; 
          double salarioTotal; 

          printf("Ingrese porcentaje de ventas para empleado categoria C: ");
          scanf("%lf", &porcentajeVentas); 

          salarioTotal = salarioBaseComision + 0.046 * porcentajeVentas; 
          cantidadEmpleadosComision++;
          totalSueldoEmpleadosComision += salarioTotal;

          printf("Monto a pagar empleado categoria C: %.2f dólares\n", salarioTotal);
          break;
        }
      default: 
      printf("Categoria inválida. Ingrese G, H o C.\n");
    }

    printf("¿Desea Ingresar el salario de un nuevo empleado?\nDigitar S para Si\nDigitar cualquier otra tecla para No: "); 
    char respuesta; 
    scanf(" %c", &respuesta);

    if(respuesta != 'S' && respuesta != 's') {
      break;
    }
  }
  int totalEmpleados = cantidadGerentes + cantidadEmpleadosHorario + cantidadEmpleadosComision;
  double totalMonto = totalSueldoGerentes + totalSueldoEmpleadosHorario + totalSueldoEmpleadosComision; 

    printf("\nResumen de Nómina:\n");
    printf("Cantidad de Gerentes: %d\n", cantidadGerentes);
    printf("Monto total para Gerentes: %.2f dólares\n", totalSueldoGerentes);

    printf("\nCantidad de Trabajadores con Horario: %d\n", cantidadEmpleadosHorario);
    printf("Monto total para Trabajadores con Horario: %.2f dólares\n", totalSueldoEmpleadosHorario);

    printf("\nCantidad de Trabajadores a Comisión: %d\n", cantidadEmpleadosComision);
    printf("Monto total para Trabajadores a Comisión: %.2f dólares\n", totalSueldoEmpleadosComision);

    printf("\nTotal de empleados: %d\n", totalEmpleados);
    printf("Monto total de la nómina: %.2f dólares\n", totalMonto);
  return 0;
}